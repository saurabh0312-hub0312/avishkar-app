package com.example.iot_controller_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
