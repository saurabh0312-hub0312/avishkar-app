import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IoT Controller App',
      theme: ThemeData(primarySwatch: Colors.green),
      home: DashboardScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String soil = "Loading...";
  String rain = "Loading...";
  double temp = 0;
  double humidity = 0;
  bool pumpOn = false;

  final String baseUrl = "http://<YOUR_PI_IP>:5000"; // replace with Pi IP later

  Future<void> fetchData() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/data"));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          temp = data["temperature"] ?? 0;
          humidity = data["humidity"] ?? 0;
          soil = data["soil_moisture"];
          rain = data["rain"];
        });
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  Future<void> togglePump() async {
    final state = pumpOn ? "off" : "on";
    try {
      await http.post(
        Uri.parse("$baseUrl/pump"),
        headers: {"Content-Type": "application/json"},
        body: json.encode({"state": state}),
      );
      setState(() {
        pumpOn = !pumpOn;
      });
    } catch (e) {
      print("Error controlling pump: $e");
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
    Timer.periodic(Duration(seconds: 5), (timer) => fetchData());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Smart Irrigation Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InfoCard(title: "🌡 Temperature", value: "$temp °C"),
            InfoCard(title: "💧 Humidity", value: "$humidity %"),
            InfoCard(title: "🌿 Soil", value: soil),
            InfoCard(title: "☔ Rain", value: rain),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: togglePump,
              style: ElevatedButton.styleFrom(
                backgroundColor: pumpOn ? Colors.red : Colors.green,
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: Text(
                pumpOn ? "TURN OFF PUMP" : "TURN ON PUMP",
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final String title;
  final String value;
  InfoCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(value, style: TextStyle(fontSize: 20, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}
